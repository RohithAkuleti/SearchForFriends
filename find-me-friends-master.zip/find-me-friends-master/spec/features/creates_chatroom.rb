require 'rails_helper'

Rspec.feature "Chatroom is created when a friend status changed from pending to accepted", type :feature, js: true do
pending

end
