# Be sure to restart your server when you modify this file.

# Enable per-form CSRF tokens.
Rails.application.config.action_controller.per_form_csrf_tokens = true
