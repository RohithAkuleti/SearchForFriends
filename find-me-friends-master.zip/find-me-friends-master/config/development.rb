Rails.application.configure do
  config.action_cable.url = "ws://localhost:3000/cable"
end