class Admin::DashboardController < AdminController
  # dashboard to show links to everything an admin can do 
  def show
  end
end
