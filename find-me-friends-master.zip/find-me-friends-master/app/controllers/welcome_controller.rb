class WelcomeController < ApplicationController
  # public welcome page
  def index
  end

  def show
  end
end
