class TosController < ApplicationController

  def index
  end

end
