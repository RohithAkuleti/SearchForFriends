class ApplicationMailer < ActionMailer::Base
  default from: 'wyatt.dev.test@gmail.com'
  layout 'mailer'
end
